# -*- coding: utf-8 -*-
from random import uniform, sample
from numpy import *
from copy import deepcopy

class TransE:
    def __init__(self):
        pass

    def init(self, dim):
        return uniform(-6 / (self.dim ** 0.5), 6 / (self.dim ** 0.5))

    ##################################
    #
    # 根据关系图谱，训练h,t,r向量
    # 参数含义：
    # iteration_num:迭代次数  subsample_nu:每次从子集合获取的数目
    # margin:松弛系数 learingRate:学习速率
    # L1:TURE 代表快速学习，精度低；FALSE 代表慢速学习，精度高
    # write_relationVector_path、write_entityVector_path写入路径
    ##################################

    def initialize(self, dirEntity = "entity2id", dirRelation = "relation2id", dirTrain = "train", dim = 10):
        '''
        初始化向量
        '''
        self.dim = dim  # 向量维度
        # 一开始，entityList是entity的list；初始化后，变为字典，key是entity，values是其向量（使用narray）。
        self.entityList = self.openDetailsAndId(dirEntity)
        self.relationList = self.openDetailsAndId(dirRelation)
        self.tripleList = self.openTrain(dirTrain)
        self.loss = 0
        self.loss2=[]
        entityVectorList = {}
        relationVectorList = {}
        for entity in self.entityList:
            n = 0
            entityVector = []
            while n < self.dim:
                ram = self.init(self.dim)#初始化的范围
                entityVector.append(ram)
                n += 1
            entityVector = self.norm(entityVector)#归一化
            entityVectorList[entity] = entityVector
        for relation in self. relationList:
            n = 0
            relationVector = []
            while n < self.dim:
                ram = self.init(self.dim)#初始化的范围
                relationVector.append(ram)
                n += 1
            relationVector = self.norm(relationVector)#归一化
            relationVectorList[relation] = relationVector
        self.entityList = entityVectorList
        self.relationList = relationVectorList


    ##################################
    #
    #根据关系图谱，训练h,t,r向量
    #参数含义：
    #iteration_num:迭代次数  subsample_nu:每次从子集合获取的数目
    #margin:松弛系数 learingRate:学习速率
    #L1:TURE 代表快速学习，精度低；FALSE 代表慢速学习，精度高
    #write_relationVector_path、write_entityVector_path写入路径
    #返回值：
    #误差，越接近0越好
    ##################################

    def transE(self, iteration_num = 20,subsample_num=3,margin = 1,learingRate = 0.00001, L1 = True,
               write_relationVector_path="relationVector.txt",write_entityVector_path="entityVector.txt"):

        print("训练开始")
        self.margin = margin
        self.learingRate = learingRate
        self.L1 = L1

        for cycleIndex in range(iteration_num):
            Sbatch = self.getSample(subsample_num)
            Tbatch = []#元组对（原三元组，打碎的三元组）的列表 ：[((h,r,t),(h',r,t'))]
            for sbatch in Sbatch:
                tripletWithCorruptedTriplet = (sbatch, self.getCorruptedTriplet(sbatch))
                if(tripletWithCorruptedTriplet not in Tbatch):
                    Tbatch.append(tripletWithCorruptedTriplet)
            self.update(Tbatch)
            print("第%d次循环"%cycleIndex)
        self.writeRelationVector(write_relationVector_path)
        self.writeEntilyVector(write_entityVector_path)
        return self.loss2

    def getSample(self, size):
        return sample(self.tripleList, size)

    def getCorruptedTriplet(self, triplet):
        '''
        training triplets with either the head or tail replaced by a random entity (but not both at the same time)
        :param triplet:
        :return corruptedTriplet:
        '''
        i = uniform(-1, 1)
        entityTemp=0
        if i < 0:#小于0，打坏三元组的第一项
            while True:
                entityTemp = sample(self.entityList.keys(), 1)[0]
                if entityTemp != triplet[0]:
                    break
            corruptedTriplet = (entityTemp, triplet[1], triplet[2])
        else:#大于等于0，打坏三元组的第三项
            while True:
                entityTemp = sample(self.entityList.keys(), 1)[0]
                if entityTemp != triplet[2]:
                    break
            corruptedTriplet = (triplet[0], triplet[1],entityTemp)
        return corruptedTriplet

    def distanceL1(self,h, t, r):
        s = h + r - t
        sum = fabs(s).sum()
        return sum

    def distanceL2(self,h, t, r):
        s = h + r - t
        sum = (s * s).sum()
        return sum

    def norm(self,list):
        var = linalg.norm(list)
        i = 0
        while i < len(list):
            list[i] = list[i] / var
            i += 1
        return array(list)

    def update(self, Tbatch):
        copyEntityList = deepcopy(self.entityList)
        copyRelationList = deepcopy(self.relationList)

        for tripletWithCorruptedTriplet in Tbatch:

            headEntityVector = copyEntityList[tripletWithCorruptedTriplet[0][0]]#tripletWithCorruptedTriplet是原三元组和打碎的三元组的元组tuple
            tailEntityVector = copyEntityList[tripletWithCorruptedTriplet[0][2]]
            relationVector = copyRelationList[tripletWithCorruptedTriplet[0][1]]
            headEntityVectorWithCorruptedTriplet = copyEntityList[tripletWithCorruptedTriplet[1][0]]
            tailEntityVectorWithCorruptedTriplet = copyEntityList[tripletWithCorruptedTriplet[1][2]]
            
            headEntityVectorBeforeBatch = self.entityList[tripletWithCorruptedTriplet[0][0]]#tripletWithCorruptedTriplet是原三元组和打碎的三元组的元组tuple
            tailEntityVectorBeforeBatch = self.entityList[tripletWithCorruptedTriplet[0][2]]
            relationVectorBeforeBatch = self.relationList[tripletWithCorruptedTriplet[0][1]]
            headEntityVectorWithCorruptedTripletBeforeBatch = self.entityList[tripletWithCorruptedTriplet[1][0]]
            tailEntityVectorWithCorruptedTripletBeforeBatch = self.entityList[tripletWithCorruptedTriplet[1][2]]
            
            if self.L1:
                distTriplet = self.distanceL1(headEntityVectorBeforeBatch, tailEntityVectorBeforeBatch, relationVectorBeforeBatch)
                distCorruptedTriplet = self.distanceL1(headEntityVectorWithCorruptedTripletBeforeBatch, tailEntityVectorWithCorruptedTripletBeforeBatch ,  relationVectorBeforeBatch)
            else:
                distTriplet = self.distanceL2(headEntityVectorBeforeBatch, tailEntityVectorBeforeBatch, relationVectorBeforeBatch)
                distCorruptedTriplet = self.distanceL2(headEntityVectorWithCorruptedTripletBeforeBatch, tailEntityVectorWithCorruptedTripletBeforeBatch ,  relationVectorBeforeBatch)
            eg = self.margin + distTriplet - distCorruptedTriplet
            self.loss2.append(eg-self.margin)
            if eg > 0:
                self.loss += eg
                if self.L1:
                    tempPositive = 2 * self.learingRate * (tailEntityVectorBeforeBatch - headEntityVectorBeforeBatch - relationVectorBeforeBatch)
                    tempNegtative = 2 * self.learingRate * (tailEntityVectorWithCorruptedTripletBeforeBatch - headEntityVectorWithCorruptedTripletBeforeBatch - relationVectorBeforeBatch)
                    tempPositiveL1 = []
                    tempNegtativeL1 = []
                    for i in range(self.dim):#不知道有没有pythonic的写法（比如列表推倒或者numpy的函数）？
                        if tempPositive[i] >= 0:
                            tempPositiveL1.append(1)
                        else:
                            tempPositiveL1.append(-1)
                        if tempNegtative[i] >= 0:
                            tempNegtativeL1.append(1)
                        else:
                            tempNegtativeL1.append(-1)
                    tempPositive = array(tempPositiveL1)  
                    tempNegtative = array(tempNegtativeL1)

                else:
                    tempPositive = 2 * self.learingRate * (tailEntityVectorBeforeBatch - headEntityVectorBeforeBatch - relationVectorBeforeBatch)
                    tempNegtative = 2 * self.learingRate * (tailEntityVectorWithCorruptedTripletBeforeBatch - headEntityVectorWithCorruptedTripletBeforeBatch - relationVectorBeforeBatch)
    
                headEntityVector = headEntityVector + tempPositive
                tailEntityVector = tailEntityVector - tempPositive
                relationVector = relationVector + tempPositive - tempNegtative
                headEntityVectorWithCorruptedTriplet = headEntityVectorWithCorruptedTriplet - tempNegtative
                tailEntityVectorWithCorruptedTriplet = tailEntityVectorWithCorruptedTriplet + tempNegtative

                #只归一化这几个刚更新的向量，而不是按原论文那些一口气全更新了
                copyEntityList[tripletWithCorruptedTriplet[0][0]] = self.norm(headEntityVector)
                copyEntityList[tripletWithCorruptedTriplet[0][2]] = self.norm(tailEntityVector)
                copyRelationList[tripletWithCorruptedTriplet[0][1]] = self.norm(relationVector)
                copyEntityList[tripletWithCorruptedTriplet[1][0]] = self.norm(headEntityVectorWithCorruptedTriplet)
                copyEntityList[tripletWithCorruptedTriplet[1][2]] = self.norm(tailEntityVectorWithCorruptedTriplet)
                
        self.entityList = copyEntityList
        self.relationList = copyRelationList

    def openDetailsAndId(self,dir, sp=","):
        idNum = 0
        list = []
        with open(dir) as file:
            lines = file.readlines()
            for line in lines:
                DetailsAndId = line.decode('utf-8').strip().split(sp)
                list.append(DetailsAndId[0])
                idNum += 1
        return list

    def openTrain(self,dir, sp=","):
        num = 0
        list = []
        with open(dir) as file:
            lines = file.readlines()
            for line in lines:
                triple = line.decode('utf-8').strip().split(sp)
                if (len(triple) < 3):
                    continue
                list.append(tuple(triple))
                num += 1
        return list

    def writeEntilyVector(self, dir):
        print("写入实体")
        entityVectorFile = open(dir, 'w')
        for entity in self.entityList.keys():
            entityVectorFile.write(entity.encode('utf-8'))
            entityVectorFile.write(str(self.entityList[entity].tolist()))
            entityVectorFile.write("\n")
        entityVectorFile.close()

    def writeRelationVector(self, dir):
        print("写入关系")
        relationVectorFile = open(dir, 'w')
        for relation in self.relationList.keys():
            relationVectorFile.write(relation.encode('utf-8'))
            relationVectorFile.write(str(self.relationList[relation].tolist()))
            relationVectorFile.write("\n")
        relationVectorFile.close()
if __name__ == '__main__':

    print("打开TransE")

    transE = TransE()
    print("TranE初始化")
    transE.initialize()
    a=transE.transE()
    print(a)



