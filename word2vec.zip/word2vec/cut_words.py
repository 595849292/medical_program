# -*- coding:utf-8 -*-
import jieba
import jieba.analyse
#######################
#
#分词
#
#######################

def cut_words(sentence):
    return " ".join(jieba.cut(sentence)).encode('utf-8')

f = open("wiki.zh.text.jian.txt")
target = open("wiki.zh.text.jian.seg.txt", 'a+')
print 'open files:'
line = f.readlines(100000)
num_n = 0
while line:
    curr = []
    num_n += 1
    for online in line:
        curr.append(online)
    after_cut = map(cut_words, curr)
    target.writelines(after_cut)
    print 'saved %d00000 articles' % num_n
    line = f.readlines(100000)

f.close()
target.close()