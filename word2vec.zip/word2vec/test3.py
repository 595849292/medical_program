# -*- coding: utf8 -*-
import gensim
model = gensim.models.Word2Vec.load("wiki.zh.text.model")
w=model.most_similar(u"太古")
for each in w:
    print(each)