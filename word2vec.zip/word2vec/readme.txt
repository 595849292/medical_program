wiki.zh.text.jian.txt 为原始文档，是原始词库。

wiki.zh.text.jian.seg.txt 为用jibe进行中文分词之后的结果。

python train_word2vec_model.py wiki.zh.text.jian.seg.txt wiki.zh.text.model wiki.zh.text.vector 是用word2vec训练之后的结果

test3.py 是演示文档