# -*- coding: utf-8 -*-

# Scrapy settings for topgoods project
#
# For simplicity, this file contains only the most important settings by
# default. All the other settings are documented here:
#
#     http://doc.scrapy.org/en/latest/topics/settings.html
#

BOT_NAME = 'topgoods'

SPIDER_MODULES = ['topgoods.spiders']
NEWSPIDER_MODULE = 'topgoods.spiders'

#DOWNLOADER_MIDDLEWARES = {'scrapy.contrib.downloadermiddleware.httpproxy.HttpProxyMiddleware':301}
#'scrapy.pipelines.images.ImagesPipeline': 1,
#'topgoods.pipelines.JsonWithEncodingPipeline': 300,  # 保存到文件中
ITEM_PIPELINES = {
    'topgoods.pipelines.TopgoodsPipeline': 300,  # 保存到mysql数据库

}

#IMAGES_URLS_FIELD = 'file_urls'
#IMAGES_STORE = r'.'
# IMAGES_THUMBS = {
    # 'small': (50, 50),
    # 'big': (270, 270),
# }
#USER_AGENT='Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36'
#Mysql数据库的配置信息
MYSQL_HOST = 'localhost'
MYSQL_DBNAME = 'testdb'         #数据库名字
MYSQL_USER = 'root'             #数据库账号
MYSQL_PASSWD = 'root'         #数据库密码
MYSQL_PORT = 3306               #数据库端口


LOG_FILE = "scrapy3.log"
