# -*- coding: utf-8 -*-
import scrapy
from topgoods.items import TopgoodsItem
class TmGoodsSpider(scrapy.Spider):
    name = "tm_goods"
    #allowed_domains = ["http://finance.qq.com/hgjj.htm"]
    #website=['http://finance.qq.com/hgjj.htm','http://business.sohu.com/FinancialNews/']
    start_urls = ('http://www.haodf.com/jibing/fuke/list.htm',)
    def parse(self, response):
        divs = response.xpath("//*[@id='el_result_content']/div/div[2]/div[2]/ul[1]")

        #item = TopgoodsItem()
        for div in divs:
            #item=TopgoodsItem()
            content= div.xpath("li/a/text()").extract()
            #item["GOODS_PRICE"] = div.xpath("li/a/text()").extract()
            url1 = div.xpath("li/a/@href").extract()
            for i in range(0,len(content)):
                item = TopgoodsItem()
                item["illness_name"]=content[i]
                url='http://www.haodf.com'+url1[i]
                yield scrapy.Request(url=url,meta={'item':item},callback=self.parse_detail,dont_filter=True)
    def parse_detail(self, response):
        div = response.xpath('//*[@id="disease"]/div/div/div[1]/p')

        if not div:
            self.log("Detail Page error--%s" % response.url)
        item = response.meta['item']
        inf= div.xpath("string(.)")[0].extract()
        #item["SHOP_NAME"]=inf.replace('\n','')
        item["illness_description"]=inf.replace('\r','').replace('\n','').replace(' ','')

        yield item

