from scrapy import cmdline
cmdline.execute("scrapy crawl tm_goods".split())