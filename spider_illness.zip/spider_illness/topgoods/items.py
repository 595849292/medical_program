# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class TopgoodsItem(scrapy.Item):
    # define the fields for your item here like:
    illness_name = scrapy.Field()
    #GOODS_NAME = scrapy.Field()
    #GOODS_URL = scrapy.Field()
    illness_description = scrapy.Field()
    #SHOP_URL = scrapy.Field()
    #COMPANY_NAME = scrapy.Field()
    #COMPANY_ADDRESS = scrapy.Field()
    
    #图片链接
    #file_urls = scrapy.Field()
    
