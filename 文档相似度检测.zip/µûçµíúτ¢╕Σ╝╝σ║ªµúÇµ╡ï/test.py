# -*- coding=utf-8 -*-
from simility import Simility_comparison
import os
if __name__ == '__main__':
    #d=Simility_comparison()
    #d.comparison('/Users/youlinqing/PycharmProjects/similarity')
    print(os.path.abspath('__file__'))